﻿using System;
using System.IO;
using Anything2Home.Droid.DataBase;
using Anything2Home.Interface;
using SQLite;
using Xamarin.Forms;

[assembly: Dependency(typeof(SqliteService))]

namespace Anything2Home.Droid.DataBase
{
    public class SqliteService : ISQLite
    {
        public SqliteService()
        {
        }

        public SQLiteConnection GetConnection()
        {
            try
            {
                var sqliteFilename = "Anything2Home.db3";
                //  string documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal); // Documents folder
                //var path = Path.Combine(documentsPath, sqliteFilename);
                var path = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), sqliteFilename);
                //Console.WriteLine(path);
                //if (!File.Exists(path)) File.Create(path);
               // var plat = new SQLite.Net.Platform.XamarinAndroid.SQLitePlatformAndroid();
                var conn = new SQLiteConnection( path,false);
                // Return the database connection
                return conn;
            }

            catch (Exception ex)
            {
                return null;
            }
        }

        #region ISQLite implementation




        //SQLiteConnection ISQLite.GetConnection()
        //{
        //    try
        //    {
        //        var sqliteFilename = "Anything2Home.db3";
        //      //  string documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal); // Documents folder
        //        //var path = Path.Combine(documentsPath, sqliteFilename);
        //        var path = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), sqliteFilename);
        //        //Console.WriteLine(path);
        //        //if (!File.Exists(path)) File.Create(path);
        //        var plat = new SQLite.Net.Platform.XamarinAndroid.SQLitePlatformAndroid();
        //        var conn = new SQLiteConnection(plat,path);
        //        // Return the database connection
        //        return conn;
        //    }

        //    catch (Exception ex)
        //    {
        //        return null;
        //    }
        //}

        #endregion ISQLite implementation
    }
}
