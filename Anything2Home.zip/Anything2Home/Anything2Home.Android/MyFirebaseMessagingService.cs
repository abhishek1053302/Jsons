﻿using System.Collections.Generic;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Support.V4.App;
using Firebase.Messaging;
using Newtonsoft.Json;

namespace Anything2Home.Droid
{
	[Service]
	[IntentFilter(new[] { "com.google.firebase.MESSAGING_EVENT", "com.google.android.c2dm.intent.RECEIVE" })]
	public class MyFirebaseMessagingService : Firebase.Messaging.FirebaseMessagingService
	{
		NotificationManager notificationManager;
		const string channelId = "default";
		const string channelName = "Default";
		bool channelInitialized = false;
		int messageId = -1;
		const int pendingIntentId = 0;
		public override void OnMessageReceived(RemoteMessage message)
		{
			base.OnMessageReceived(message);

			SendNotification(message?.Data, message?.GetNotification()?.Title);
		}

		private void SendNotification(IDictionary<string, string> data, string title)
		{
			messageId++;

			Intent intent = new Intent(this, typeof(MainActivity));
			intent.PutExtra(nameof(Notification), title);
			intent.AddFlags(ActivityFlags.ClearTop);


			var notificationJsonObject = FromDictionaryToJson(data);

			Anything2Home.Models.Notification notificationData = JsonConvert.DeserializeObject<Anything2Home.Models.Notification>(notificationJsonObject);
			var fullScreenPendingIntent = PendingIntent.GetActivity(this.ApplicationContext, pendingIntentId, intent, PendingIntentFlags.OneShot);

			NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
			.SetContentIntent(fullScreenPendingIntent)
				.SetContentTitle(notificationData?.NotificationTitle)
				.SetContentText(notificationData?.NotificationDescription)
				.SetSmallIcon(Resource.Drawable.icon);

			/// Build the notification:
			Notification notification = builder.Build();
			notification.Flags = NotificationFlags.AutoCancel;

			/// Get the notification manager:
			notificationManager =
			   GetSystemService(Context.NotificationService) as NotificationManager;

			/// Publish the notification: 
			notificationManager.Notify(messageId, notification);


		}
		public static string FromDictionaryToJson(IDictionary<string, string> dictionary)
		{
			var jsonObject = dictionary.Select(kvp => string.Format("\"{0}\":\"{1}\",", kvp.Key, kvp.Value));
			return string.Concat("{", string.Join("", jsonObject), "}");
		}
	}
}
