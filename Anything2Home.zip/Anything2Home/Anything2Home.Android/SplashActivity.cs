﻿using System;
using Android.App;
using Android.Support.V7.App;

namespace Anything2Home.Droid
{
    [Activity(Label = "Anything2Home", Icon = "@drawable/icon", Theme = "@style/splashscreen", MainLauncher = false, NoHistory = true)]
    public class SplashActivity : AppCompatActivity
    {
        protected override void OnResume()
        {
            base.OnResume();
            StartActivity(typeof(SplashActivity));
        }
    }
}
