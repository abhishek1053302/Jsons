﻿using System;
using Android.App;
using Firebase.Iid;


namespace Anything2Home.Droid
{
    [Service]
    [IntentFilter(new[] { "com.google.firebase.INSTANCE_ID_EVENT" })]
    public class FirebaseIIDService : FirebaseInstanceIdService
    {
        const string TAG = nameof(FirebaseIIDService);
        public override void OnTokenRefresh()
        {
            var refreshedToken = FirebaseInstanceId.Instance.Token;
            SendToServer(refreshedToken);
            Console.WriteLine("Token" + refreshedToken);
        }
        public void SendToServer(string token)
        {
            // To do
        }
    }
}
