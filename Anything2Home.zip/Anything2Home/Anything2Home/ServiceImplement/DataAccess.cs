﻿using System;
using System.Collections.Generic;
using System.Linq;
using Anything2Home.Interface;
using Anything2Home.Models;
using SQLite;
using Xamarin.Forms;

namespace Anything2Home.ServiceImplement
{
    public class DataAccess
    {
        private SQLiteConnection dbConn;

        public DataAccess()
        {
            dbConn = DependencyService.Get<ISQLite>().GetConnection();
            // create the table(s)
         
                dbConn.CreateTable<Products>();
                dbConn.CreateTable<Address>();
           
           

        }

        public List<Products> GetAllProducts()
        {
            // return dbConn.Query<Products>("Select * From [Products]");
            return (from data in dbConn.Table<Products>() select data).ToList();
        }

        public int SaveProduct(Products aProduct)
        {
            return dbConn.Insert(aProduct);
        }
        public Products GetProductsData(int id)
        {
            return dbConn.Table<Products>().FirstOrDefault(t => t.Id == id);
        }

        public int DeleteProduct(int id)
        {
            return dbConn.Delete<Products>(id);
        }

        public int EditProduct(Products aProduct)
        {
            return dbConn.Update(aProduct);
        }
        public List<Address> GetAllAddress()
        {
            return (from data in dbConn.Table<Address>() select data).ToList();

        }
        public Address GetAddressData(int id)
        {
            return dbConn.Table<Address>().FirstOrDefault(t => t.Id == id);
        }
        public int SaveAddress(Address address)
        {
            return dbConn.Insert(address);
        }

        public int DeleteAddress(int id)
        {
            return dbConn.Delete<Address>(id);
        }

        public int EditAddress(Address address)
        {
            return dbConn.Update(address);
        }
    }
}
