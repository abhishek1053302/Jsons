﻿using System;
using System.Collections.Generic;
using Anything2Home.Models;

namespace Anything2Home.ServiceImplement.ServiceInterface
{
    public interface IAddressService
    {
        List<Address> GetAllAddressData();

        //Get Specific Address data  
        Address GetAddressData(int addressid);

        // Delete all Address Data  
        void DeleteAllAddress();

        // Delete Specific Address  
        void DeleteAddress(int addressid);

        // Insert new Address to DB   
        void InsertAddress(Address contact);

        // Update Address Data  
        void UpdateAddress(Address contact);
    }
}
