﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Anything2Home.Models;

namespace Anything2Home.ServiceImplement.ServiceInterface
{
    public interface IProductService
    {
        Task<List<Products>> GetProducts();

    }
}
