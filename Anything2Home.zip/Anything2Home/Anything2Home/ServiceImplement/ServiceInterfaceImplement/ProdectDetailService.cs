﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Anything2Home.Manager;
using Anything2Home.Models;
using Anything2Home.ServiceImplement.ServiceInterface;
using Anything2Home.ServiceImplement.ServiceInterfaceImplement;
using Xamarin.Forms;

[assembly: Dependency(typeof(ProdectDetailService))]

namespace Anything2Home.ServiceImplement.ServiceInterfaceImplement
{
    public class ProdectDetailService : IProductService
    {
        public List<Products> ProductDetails;
        public HttpManager httpManager;

        public ProdectDetailService()
        {
            ProductDetails = new List<Products>();
            httpManager = new HttpManager();
        }

        public async Task<List<Products>> GetProducts()
        {
            var response = await httpManager.GetAsync<Products>(Constants.ProductBn);

            return response;
        }
    }
}
