﻿using System;
using System.Collections.Generic;
using Anything2Home.Models;
using Anything2Home.ServiceImplement.ServiceInterface;

namespace Anything2Home.ServiceImplement.ServiceInterfaceImplement
{
    public class AddressService : IAddressService
    {
        DataAccess _dataAccess;
        public AddressService()
        {
            _dataAccess = new DataAccess();
        }

        public void DeleteAddress(int addressid)
        {
            _dataAccess.DeleteAddress(addressid);
        }

        public void DeleteAllAddress()
        {
            throw new NotImplementedException();
        }

        public Address GetAddressData(int addressid)
        {
            return _dataAccess.GetAddressData(addressid);
        }

        public List<Address> GetAllAddressData()
        {
            return _dataAccess.GetAllAddress();
        }

        public void InsertAddress(Address contact)
        {
            _dataAccess.SaveAddress(contact);
        }

        public void UpdateAddress(Address contact)
        {
            _dataAccess.EditAddress(contact);
        }
    }
}
