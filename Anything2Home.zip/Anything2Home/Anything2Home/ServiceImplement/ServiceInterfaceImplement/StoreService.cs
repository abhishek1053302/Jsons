﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Anything2Home.Manager;
using Anything2Home.Models;
using Anything2Home.ServiceImplement.ServiceInterface;

namespace Anything2Home.ServiceImplement.ServiceInterfaceImplement
{
    public class StoreService : IStoreService
    {
        public List<Store> StoreDetails;
        public HttpManager httpManager;

        public StoreService()
        {
            StoreDetails = new List<Store>();
            httpManager = new HttpManager();
        }
        public async Task<List<Store>> GetStore()
        {
            var response = await httpManager.GetAsync<Store>(Constants.StoreBn);
            return response;

        }
    }
}
