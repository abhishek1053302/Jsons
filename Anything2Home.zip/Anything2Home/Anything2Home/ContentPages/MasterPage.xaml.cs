﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Anything2Home.ContentPages
{
    public partial class MasterPage : ContentPage
    {
        public MasterPage()
        {
            InitializeComponent();
        }
    }
}
