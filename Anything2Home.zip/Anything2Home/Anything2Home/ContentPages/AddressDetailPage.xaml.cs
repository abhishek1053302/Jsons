﻿using System;
using System.Collections.Generic;
using Anything2Home.ViewModel;
using Xamarin.Forms;

namespace Anything2Home.ContentPages
{
    public partial class AddressDetailPage : ContentPage
    {
        public AddressDetailPage()
        {
            InitializeComponent();
            this.BindingContext = new AddAddressViewModel();

        }
    }
}
