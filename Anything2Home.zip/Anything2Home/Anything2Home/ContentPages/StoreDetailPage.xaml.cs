﻿using System;
using System.Collections.Generic;
using Anything2Home.ViewModel;
using Xamarin.Forms;

namespace Anything2Home.ContentPages
{
    public partial class StoreDetailPage : ContentPage
    {
        public StoreDetailPage()
        {
            InitializeComponent();
            this.BindingContext = new StoreDetailViewModel();
        }
    }
}
