﻿using System;
using System.Collections.Generic;
using Anything2Home.ViewModel;
using Xamarin.Forms;

namespace Anything2Home.ContentPages
{
    public partial class AddressPage : ContentPage
    {
        public AddressPage()
        {

            ViewModel = new AddressViewModel();
            InitializeComponent();
            this.BindingContext = new AddressViewModel();

        }
        protected override void OnAppearing()
        {
            ViewModel.GetAddress();
            base.OnAppearing();
        }
        public AddressViewModel ViewModel
        {
            get { return BindingContext as AddressViewModel; }
            set { BindingContext = value; }
        }
        //private void OnRatingChanged(object sender, float e)
        //{
        //    customRatingBar.Rating = e;
        //}
    }
}
