﻿using System;
using System.Collections.Generic;
using Anything2Home.ViewModel;
using Xamarin.Forms;

namespace Anything2Home.ContentPages
{
    public partial class ProductPage : ContentPage
    {
        public ProductPage()
        {
            InitializeComponent();
            this.BindingContext = new ProductViewModel();

        }
    }
}
