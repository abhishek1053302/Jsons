﻿using System;
using System.Collections.Generic;
using System.Linq;
using Anything2Home.ViewModel;
using Xamarin.Forms;

namespace Anything2Home.ContentPages
{
    public partial class StorePage : ContentPage
    {
        public StorePage()
        {
            InitializeComponent();
            this.BindingContext = new StoreViewModel();

        }
        void Handle_TextChanged(object sender, Xamarin.Forms.TextChangedEventArgs e)
        {
            var _container = BindingContext as StoreViewModel;
            StoreListView.BeginRefresh();

            if (string.IsNullOrWhiteSpace(e.NewTextValue))
                StoreListView.ItemsSource = _container.Stores;
            else
                StoreListView.ItemsSource = _container.Stores.Where(i => i.storename.Contains(e.NewTextValue));

            StoreListView.EndRefresh();
        }
    }
}
