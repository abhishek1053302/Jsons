﻿using System;
using System.Collections.Generic;
using Anything2Home.ViewModel;
using Xamarin.Forms;

namespace Anything2Home.ContentPages
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            InitializeComponent();
            this.BindingContext = new LoginViewModel();

        }
    }
}
