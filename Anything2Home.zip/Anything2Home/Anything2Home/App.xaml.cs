﻿using Anything2Home.ContentPages;
using Xamarin.Forms;
using Anything2Home.ServiceImplement;
using Anything2Home.Models;
using App.User.LocationInfo.Models;
using App.User.LocationInfo.Services;

namespace Anything2Home
{
    public partial class App : Application
    {
        private static DataAccess dbUtils;
        public UserLocationInfo UserLocationInfo { get; set; }
        public string GpsPosition { get; set; }
        public App()
        {
            InitializeComponent();
            if (string.IsNullOrEmpty(Constants.CityName))
            {
                TrackUser();
            }
            MainPage = new NavigationPage(new AddressPage());
        }
        async void TrackUser()
        {
            UserLocationInfo = await TrackingService.GetLocationInfoAsync();
            if (UserLocationInfo != null)
            {
                GpsPosition = "(" + UserLocationInfo.Location.Latitude + ", " + UserLocationInfo.Location.Longitude + ")";
                Constants.CityName = UserLocationInfo.City;
            }
        }
        public static DataAccess DAUtil
        {
            get
            {
                if (dbUtils == null)
                {
                    dbUtils = new DataAccess();
                }
                return dbUtils;
            }
        }
        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
