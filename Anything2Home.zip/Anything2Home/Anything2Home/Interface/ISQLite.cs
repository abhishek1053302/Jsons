﻿using System;
using SQLite;

namespace Anything2Home.Interface
{
    public interface ISQLite
    {
        SQLiteConnection GetConnection();
    }
}
