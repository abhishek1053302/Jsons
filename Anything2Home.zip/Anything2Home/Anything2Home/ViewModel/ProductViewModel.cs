﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Anything2Home.Models;
using Anything2Home.ServiceImplement.ServiceInterfaceImplement;

namespace Anything2Home.ViewModel
{
    public class ProductViewModel : INotifyPropertyChanged
    {
        public ProdectDetailService prodectDetailService;

        public ProductViewModel()
        {
            prodectDetailService = new ProdectDetailService();
            GetProducts();
        }
        private ObservableCollection<Products> products;


        public ObservableCollection<Products> Products
        {
            get { return products; }
            set
            {

                products = value;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public async void GetProducts()
        {
            try
            {
                products = new ObservableCollection<Products>();
                var respose = await prodectDetailService.GetProducts();
                foreach (var item in respose)
                {
                    Products.Add(item);
                }

            }
            catch (Exception ex)
            {

            }

        }
    }
}
    
