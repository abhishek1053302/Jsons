﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Anything2Home.ContentPages;
using Anything2Home.Models;
using Anything2Home.ServiceImplement.ServiceInterfaceImplement;
using Xamarin.Forms;
namespace Anything2Home.ViewModel
{
    public class AddressViewModel : BaseAddressViewModel
    {
        public ICommand AddressCommand { protected set; get; }
        public AddressViewModel()
        {
            addressService = new AddressService();
            AddressCommand = new Command(AddAddress);
            Address = new ObservableCollection<Address>();
        }
        public ObservableCollection<Address> Address { get; private set; }
           = new ObservableCollection<Address>();

       
        public async void AddAddress()
        {
            await App.Current.MainPage.Navigation.PushAsync(new AddressDetailPage());

        }
        public async Task  GetAddress()
        {
            try
            {

                var respose = addressService.GetAllAddressData();
                foreach (var item in respose)
                {
                    Address.Add(item);
                }
            }
            catch (Exception ex)
            {

            }

        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
