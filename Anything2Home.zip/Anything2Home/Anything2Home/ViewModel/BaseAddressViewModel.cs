﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Anything2Home.Models;
using Anything2Home.ServiceImplement.ServiceInterface;
using Anything2Home.ServiceImplement.ServiceInterfaceImplement;

namespace Anything2Home.ViewModel
{
    public class BaseAddressViewModel : INotifyPropertyChanged
    {
        public Address _address;
        public AddressService addressService;
        public BaseAddressViewModel()
        {
        }
        public string AddressType
        {
            get => _address.AddressType;
            set
            {
                _address.AddressType = value;
                NotifyPropertyChanged("AddressType");
            }


        }



        public string HouseNo
        {
            get => _address.HouseNo;
            set
            {
                _address.HouseNo = value;
                NotifyPropertyChanged("HouseNo");
            }
        }
        public string Community
        {
            get => _address.Community;
            set
            {
                _address.Community = value;
                NotifyPropertyChanged("Community");
            }
        }

        public string Area
        {
            get => _address.Area;
            set
            {
                _address.Area = value;
                NotifyPropertyChanged("Area");
            }
        }
        public string City
        {
            get => _address.City;
            set
            {
                _address.City = value;
                NotifyPropertyChanged("City");
            }
        }
        public string PinCode
        {
            get => _address.PinCode;
            set
            {
                _address.PinCode = value;
                NotifyPropertyChanged("PinCode");
            }
        }
        public String FullAddress
        {
            get { return HouseNo + " " + _address.Community + " " + _address.Area + " " + _address.City + " " + _address.PinCode + " " + _address.Country; }
        }
        public string Country
        {
            get => _address.Country;
            set
            {
                _address.Country = value;
                NotifyPropertyChanged("Country");
            }
        }
        #region INotifyPropertyChanged      
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion    
    }
}
