﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Anything2Home.Models;
namespace Anything2Home.ViewModel
{
    public class StoreDetailViewModel : INotifyPropertyChanged
    {
        public Store store;
        public StoreDetailViewModel()
        {
           // store = StoreDetai;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public string StoreName
        {
            get => store.storename;
            set
            {
                store.storename = value;
                NotifyPropertyChanged("AddressType");
            }


        }

    }
}
