﻿using System;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Windows.Input;
using Anything2Home.Models;
using App.User.LocationInfo.Models;
using App.User.LocationInfo.Services;
using Xamarin.Forms;
using Anything2Home.ContentPages;
using Anything2Home.Helper;

namespace Anything2Home.ViewModel
{
    public class SignUpViewModel : INotifyPropertyChanged
    {


        private string email;
        public string Email
        {
            get { return email; }
            set
            {
                email = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Email"));
            }
        }
        private UserLocationInfo _userLocationInfo;
        public UserLocationInfo UserLocationInfo
        {
            get { return _userLocationInfo; }
            set
            {
                _userLocationInfo = value;
                PropertyChanged(this, new PropertyChangedEventArgs("UserLocationInfo"));
            }
        }

        private string _gpsPosition;
        public string GpsPosition
        {
            get { return _gpsPosition; }
            set { _gpsPosition = value; PropertyChanged(this, new PropertyChangedEventArgs("GpsPosition")); }
        }
        private string password;

        public event PropertyChangedEventHandler PropertyChanged;

        public string Password
        {
            get { return password; }
            set
            {
                password = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Password"));
            }
        }
        private string phonenumber;
        public string PhoneNumber
        {
            get { return phonenumber; }
            set
            {
                phonenumber = value;
                PropertyChanged(this, new PropertyChangedEventArgs("PhoneNumber"));

            }
        }

        private string city;
        public string City
        {
            get { return city; }
            set
            {
                city = value;
                PropertyChanged(this, new PropertyChangedEventArgs("City"));

            }
        }
        private String firstname;
        private String lastName;
        public String FirstName
        {
            get { return firstname; }
            set { firstname = value; PropertyChanged(this, new PropertyChangedEventArgs("FirstName")); }
        }
        public String LastName
        {
            get { return lastName; }
            set { lastName = value; PropertyChanged(this, new PropertyChangedEventArgs("LastName")); }
        }
        public String FullName
        {
            get { return firstname + " " + lastName; }
        }
        public ICommand SubmitCommand { protected set; get; }
        public ICommand LoginCommand { protected set; get; }

        public SignUpViewModel()
        {
            SubmitCommand = new Command(OnSubmit);
            LoginCommand = new Command(OnLogin);


        }
        public async void OnLogin()
        {
            await App.Current.MainPage.Navigation.PushAsync(new LoginPage());

        }
        public async void OnSubmit()
        {
            if (string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Password))
            {
                await App.Current.MainPage.DisplayAlert("Empty Values", "Please enter Email and Password", "OK");
            }
            else
            {
                //call AddUser function which we define in Firebase helper class
                var user1 = await FirebaseHelper.GetUser(Email);
                if (user1 != null)
                {
                    if (user1.Email == Email)
                    {
                        await App.Current.MainPage.DisplayAlert("Duplicate", "Email already taken. Please Login", "OK");

                    }
                }
                else
                {
                    var user = await FirebaseHelper.AddUser(Email, Password, City, PhoneNumber);

                    //AddUser return true if data insert successfuly     
                    if (user)
                    {
                        await App.Current.MainPage.DisplayAlert("SignUp Success", "", "Ok");
                        //Navigate to Wellcom page after successfuly SignUp    
                        //pass user email to welcom page
                        SendMessage();

                        await App.Current.MainPage.Navigation.PushModalAsync(new MainPage());
                    }
                    else
                        await App.Current.MainPage.DisplayAlert("Error", "SignUp Fail", "OK");
                    // var product = await FirebaseHelper.GetAllProducts();
                }
            }

        }
        public string SendMessage()
        {
            string serverKey = "AAAAYlbfUGs:APA91bE1-PP9mTboGYHsA5CYezGZI6qVjIxWfnKUd01VGM9Fe_AijxImH37ZkPXWxOPTtmSA2PBWtWP-RHPC99n4_efVd66-cGiiSmCS4TpTuDmZOfYairNx01Y5EnjIdq9U6NzeT5z6";

            try
            {
                var result = "-1";
                var webAddr = "https://fcm.googleapis.com/fcm/send";

                var regID = "cA_Bo8nVHiU:APA91bHywZwtZMC4BRVCbXz2dGrFw3dzMk7RrEPghuMjvQ0iFI80tfXVsUAA68bmZ1vpaGY4fCrCL2rhToHWvmIEgLLd6N8oXPnBq6NiQbql4jw8XEfs_1estjuKbhM5HdgAoExNv8It";

                var httpWebRequest = (HttpWebRequest)WebRequest.Create(webAddr);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Headers.Add("Authorization:key=" + serverKey);
                httpWebRequest.Method = "POST";

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json = "{\"to\": \"" + regID + "\",\"data\": {\"notificationTitle\": \"Ready to order?\",\"notificationDescription\": \"Welcome to Anything2Home. Get free delivery on your first order with no minimum purchase value.\"},\"priority\":10}";
                    //registration_ids, array of strings -  to, single recipient
                    streamWriter.Write(json);
                    streamWriter.Flush();
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    result = streamReader.ReadToEnd();
                }

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return "err";
            }
        }
        async void TrackUser()
        {
            UserLocationInfo = await TrackingService.GetLocationInfoAsync();
            if (UserLocationInfo != null)
            {
                GpsPosition = "(" + UserLocationInfo.Location.Latitude + ", " + UserLocationInfo.Location.Longitude + ")";
                Constants.CityName = UserLocationInfo.City;
            }
        }
    }
}
