﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Anything2Home.ServiceImplement.ServiceInterfaceImplement;
using Xamarin.Forms;

namespace Anything2Home.ViewModel
{
    public class AddAddressViewModel : BaseAddressViewModel
    {
        public ICommand AddAddressCommand { get; private set; }

        public AddAddressViewModel()
        {
            addressService = new AddressService();
            _address = new Models.Address();
            AddAddressCommand = new Command(async () => await AddAddress());

        }
        async Task AddAddress()
        {
            addressService.InsertAddress(_address);
        }
    }
}
