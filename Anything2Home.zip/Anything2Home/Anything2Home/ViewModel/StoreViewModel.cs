﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Anything2Home.ContentPages;
using Anything2Home.Models;
using Anything2Home.ServiceImplement.ServiceInterfaceImplement;
namespace Anything2Home.ViewModel
{
    public class StoreViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public StoreService storeservice;

        private ObservableCollection<Store> stores;


        public ObservableCollection<Store> Stores
        {
            get { return stores; }
            set
            {

                stores = value;
            }
        }

        Store _storeSelectedItem;
        public Store StoreSelectedItem
        {
            get
            {
                return _storeSelectedItem;
            }

            set
            {
                _storeSelectedItem = value;
                PropertyChanged(this, new PropertyChangedEventArgs("StoreSelectedItem"));

                navigation(StoreSelectedItem);
            }
        }
        async void navigation(Store StoreSelectedItem)
        {
            await App.Current.MainPage.Navigation.PushModalAsync(new StoreDetailPage());
        }
        public StoreViewModel()
        {
            storeservice = new StoreService();
            GetProducts();
        }
        public async void GetProducts()
        {
            try
            {
                stores = new ObservableCollection<Store>();
                var respose = await storeservice.GetStore();
                foreach (var item in respose)
                {
                    Stores.Add(item);
                }

            }
            catch (Exception ex)
            {

            }

        }
    }
}
