﻿using System;
using SQLite;

namespace Anything2Home.Models
{
    public class Address
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string AddressType { get; set; }
        public string HouseNo { get; set; }
        public string Community { get; set; }
        public string Area { get; set; }
        public string City { get; set; }
        public string PinCode { get; set; }
        public string Country { get; set; }
        public String FullAddress
        {
            get { return HouseNo + " " + Community + " " + Area + " " + City + " " + PinCode + " " + Country; }
        }
    }
}
