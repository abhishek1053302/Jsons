﻿using System;
namespace Anything2Home.Models
{
    public static class Constants
    {

        public static string ProductBn = "https://raw.githubusercontent.com/abhishek1053302/Jsons/master/Product.json";
        public static string StoreBn = "https://raw.githubusercontent.com/abhishek1053302/Jsons/73652e5fc54af83d4f6a436d886b06902153c191/Store.json";
        public static string CityName = "";

    }
}
