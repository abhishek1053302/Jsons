﻿using System;
using Newtonsoft.Json;

namespace Anything2Home.Models
{
    public class Notification
    {
        [JsonProperty("notificationId")]
        public string NotificationId { get; set; }
        [JsonProperty("notificationTitle")]
        public string NotificationTitle { get; set; }
        [JsonProperty("notificationDescription")]
        public string NotificationDescription { get; set; }
    }
}
