﻿using System;
namespace Anything2Home.Models
{
    public class Store
    {
        public string id { get; set; }
        public string storename { get; set; }
        public string imageurl { get; set; }
        public string location { get; set; }
        public string description { get; set; }
    }
}
