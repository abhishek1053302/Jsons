﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using SQLite;

namespace Anything2Home.Models
{
    public class Products
    {
        [JsonIgnore]
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public string ShortDescription { get; set; }
        public string Description { get; set; }
    }
    public class Example
    {
        public IList<Products> products { get; set; }
    }
}
